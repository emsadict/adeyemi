<?php
include 'db_connect.php'; // Include database connection

// Define pagination variables
$limit = 5; // Number of researches per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max($page, 1); // Ensure the page number is at least 1
$offset = ($page - 1) * $limit;

// Fetch total number of research activities
$totalQuery = "SELECT COUNT(*) AS total FROM research_activities";
$totalResult = $conn->query($totalQuery);
$totalRow = $totalResult->fetch_assoc();
$totalResearches = $totalRow['total'];
$totalPages = ceil($totalResearches / $limit);

// Fetch research activities with pagination
$query = "SELECT id, title, abstract, principal_investigator, image, date FROM research_activities 
          ORDER BY date DESC LIMIT $limit OFFSET $offset";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
   <?php include "head.php"; ?>

</head>

<body class="home page-template-default page page-id-2039 gdlr-core-body woocommerce-no-js tribe-no-js kingster-body kingster-body-front kingster-full  kingster-with-sticky-navigation  kingster-blockquote-style-1 gdlr-core-link-to-lightbox">
<?php include "mobilemenu.php"; ?>
    <div class="kingster-body-outer-wrapper ">
        <div class="kingster-body-wrapper clearfix  kingster-with-frame">
           <?php include "headermenu.php" ?>
           <?php   include "menu.php";?>
            <div class="kingster-page-title-wrap  kingster-style-medium kingster-center-align">
                <div class="kingster-header-transparent-substitute"></div>
                <div class="kingster-page-title-overlay"></div>
                <div class="kingster-page-title-container kingster-container">
                    <div class="kingster-page-title-content kingster-item-pdlr">
                        <h1 class="kingster-page-title">EVENTS PAGE</h1></div>
                </div>
            </div>
            <div class="kingster-page-wrapper" id="kingster-page-wrapper">
    <div class="gdlr-core-page-builder-body">
        <div class="gdlr-core-pbf-sidebar-wrapper">
            <div class="gdlr-core-pbf-sidebar-container gdlr-core-line-height-0 clearfix gdlr-core-js gdlr-core-container">
                <div class="gdlr-core-pbf-sidebar-content gdlr-core-column-45 gdlr-core-pbf-sidebar-padding gdlr-core-line-height" style="padding: 60px 10px 30px 30px;">
                    <div class="gdlr-core-pbf-background-wrap" style="background-color: #f7f7f7;"></div>
                    <div class="gdlr-core-pbf-sidebar-content-inner">
<div class="gdlr-core-pbf-element">
    <div class="gdlr-core-blog-item gdlr-core-item-pdb clearfix gdlr-core-style-blog-full-with-frame" style="padding-bottom: 40px;">
        <div class="gdlr-core-blog-item-holder gdlr-core-js-2 clearfix" data-layout="fitrows">

            <!-- Upcoming Events -->
            <h3>Upcoming Events</h3>
            <hr />
            <?php if (mysqli_num_rows($upcoming_result) > 0): ?>
                <?php while ($event = mysqli_fetch_assoc($upcoming_result)): ?>
                    <div class="event-box">
                        <h3><?php echo $event['title']; ?></h3>
                        <p><?php echo $event['description']; ?></p>
                        <p><strong>Date:</strong> <?php echo $event['event_date']; ?></p>
                        <p><strong>Time:</strong> <?php echo $event['event_time']; ?></p>
                        <p><strong>Venue:</strong> <?php echo $event['event_venue']; ?></p>
                        <img src="uploads/<?php echo $event['event_thumbnail']; ?>" width="150">
                        <br>
                        <div class="pagination">
                        <a href="mainevent.php?id=<?php echo $event['id']; ?>" class="btn btn-primary">View Event</a>
                        </div>
                    </div>
                <?php endwhile; ?>
                
                <!-- Pagination for Upcoming Events -->
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="events.php?page=<?php echo $page - 1; ?>" class="btn btn-success">Previous</a>
                    <?php endif; ?>
                    
                    <?php if ($page < $total_pages_upcoming): ?>
                        <a href="events.php?page=<?php echo $page + 1; ?>" class="btn btn-success">Next</a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <p>No upcoming events found.</p>
            <?php endif; ?>

            <hr>

            <!-- Past Events -->
            <h2>Past Events</h2>
            <hr />
            <?php if (mysqli_num_rows($past_result) > 0): ?>
                <?php while ($event = mysqli_fetch_assoc($past_result)): ?>
                    <div class="event-box">
                        <h3><?php echo $event['title']; ?></h3>
                        <p><?php echo $event['description']; ?></p>
                        <p><strong>Date:</strong> <?php echo $event['event_date']; ?></p>
                        <p><strong>Time:</strong> <?php echo $event['event_time']; ?></p>
                        <p><strong>Venue:</strong> <?php echo $event['event_venue']; ?></p>
                        <img src="uploads/<?php echo $event['event_thumbnail']; ?>" width="150">
                        <br>
                        <a href="mainevent.php?id=<?php echo $event['id']; ?>" class="btn btn-primary">View Event</a>
                    </div>
                <?php endwhile; ?>

                <!-- Pagination for Past Events -->
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="events.php?page=<?php echo $page - 1; ?>" class="btn btn-primary">Previous</a>
                    <?php endif; ?>
                    
                    <?php if ($page < $total_pages_past): ?>
                        <a href="events.php?page=<?php echo $page + 1; ?>" class="btn btn-light">Next</a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <p>No past events found.</p>
            <?php endif; ?>

        </div>
    </div>
</div>

<style>
    .event-box {
        background-color: #f7f7f7;
        padding: 20px;
        margin-bottom: 20px;
        border-radius: 10px ;
        border:rgb(108, 27, 27) 4px solid;
        align-items: center;
    }
    .pagination {
        margin-top: 10px;
        padding: 10px;
    }
    .pagination a {
        margin: 2px;
        padding: 8px 12px;
        border: 1px solid #ddd;
        border-radius: 5px;
        text-decoration: none;
        background-color:rgb(20, 141, 106);
        color: #f7f7f7;
    }
    .pagination a:hover {
        background-color:rgb(5, 125, 79);
        color: white;
    }
</style>


</div>
                </div>
                
                <!-- Sidebar with Recent Posts -->
                <div class="gdlr-core-pbf-sidebar-left gdlr-core-column-extend-left kingster-sidebar-area gdlr-core-column-15 gdlr-core-pbf-sidebar-padding gdlr-core-line-height">
                    <div class="gdlr-core-sidebar-item gdlr-core-item-pdlr">
                        <div id="recent-posts-3" class="widget widget_recent_entries kingster-widget" style="background-color:rgb(206, 234, 221) ;">
                            <h3 class="kingster-widget-title">EVENTS</h3><span class="clear"></span>
                            <ul>
                                <?php
                                $recentPosts = $conn->query("SELECT id, title FROM events ORDER BY event_date DESC LIMIT 10");
                                while ($post = $recentPosts->fetch_assoc()):
                                ?>
                                    <li><a href="mainevent.php?id=<?= $post['id']; ?>"><?= $post['title']; ?></a></li>
                                <?php endwhile; ?>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<?php mysqli_close($conn); ?>


            <footer>
                <?php  include "footer.php";?>
            </footer>
        </div>
    </div>


	<script type='text/javascript' src='js/jquery/jquery.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-migrate.min.js'></script>
    <script type='text/javascript' src='plugins/goodlayers-core/plugins/combine/script.js'></script>
    <script type='text/javascript'>
        var gdlr_core_pbf = {
            "admin": "",
            "video": {
                "width": "640",
                "height": "360"
            },
            "ajax_url": "#"
        };
    </script>
    <script type='text/javascript' src='plugins/goodlayers-core/include/js/page-builder.js'></script>
    <script type='text/javascript' src='js/jquery/ui/effect.min.js'></script>
    <script type='text/javascript'>
        var kingster_script_core = {
            "home_url": "index.html"
        };
    </script>
    <script type='text/javascript' src='js/plugins.min.js'></script>
</body>
</html>