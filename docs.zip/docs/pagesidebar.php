
<h3 class="kingster-widget-title">Menu</h3><span class="clear"></span>
                                        <ul>
                                        <li> <a href="createpage.php">Create Page</a></li>
                                            <li> <a href="manage_page.php">Manage Page</a></li>
                                             <li><a href="create_page_details.php">Add Page Details</a></li>
                                             <li><a href="create_dept.php">Create A Dept</a></li>
                                             <li><a href="manage_dept.php">Manage Dept</a></li>
                                             <li><a href="addstaff.php">Add Staff</a></li>
                                        </ul> 
