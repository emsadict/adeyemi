<footer>
                <div class="kingster-footer-wrapper ">
                    <div class="kingster-footer-container kingster-container clearfix">
                 
                        <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                            <div id="gdlr-core-custom-menu-widget-1" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                <h3 class="kingster-widget-title">Our Contact</h3><span class="clear"></span>
                                <div class="menu-our-campus-container">
                                    <ul id="menu-our-campus" class="gdlr-core-custom-menu-widget gdlr-core-menu-style-plain">
                                        <li class="menu-item"><a href="#">Ondo-Ore Road, Ondo. </a></li>
                                        <li class="menu-item"><a href="#">Postal Address: P.M.B. 520</a></li>
                                        <li class="menu-item"><a href="#">Ondo State Nigeria</a></li>
                                        <p><span id="span_1dd7_11">+2348130125529; 
                                    <br />+2348035841342; 
                                    <br />+2348033252107;| CALLS: 8am-4pm,</span>
                                        <br /> <span class="gdlr-core-space-shortcode" id="span_1dd7_12"></span>
                                        <br /> <a id="a_1dd7_8" href="mailto:admin@kingsteruni.edu">admin@afued.edu.ng</a></p>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                            <div id="gdlr-core-custom-menu-widget-2" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                <h3 class="kingster-widget-title">Structure</h3><span class="clear"></span>
                                <div class="menu-our-campus-container">
                                    <ul id="menu-our-campus" class="gdlr-core-custom-menu-widget gdlr-core-menu-style-plain">
                                        <li class="menu-item"><a href="#">Acedemic</a></li>
                                        <li class="menu-item"><a href="#">directorate</a></li>
                                        <li class="menu-item"><a href="#">Units</a></li>
                                        <li class="menu-item"><a href="#">Office of the Chancellor</a></li>
                                        <li class="menu-item"><a href="#">Schools</a></li>
                                        <li class="menu-item"><a href="#">Registry</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                            <div id="gdlr-core-custom-menu-widget-3" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                <h3 class="kingster-widget-title">Campus Life</h3><span class="clear"></span>
                                <div class="menu-campus-life-container">
                                    <ul id="menu-campus-life" class="gdlr-core-custom-menu-widget gdlr-core-menu-style-plain">
                                        <li class="menu-item"><a href="#">Accessibility</a></li>
                                        <li class="menu-item"><a href="#">Financial Aid</a></li>
                                        <li class="menu-item"><a href="#">Food Services</a></li>
                                        <li class="menu-item"><a href="#">Hostel</a></li>
                                        <li class="menu-item"><a href="#">Portal</a></li>
                                        <li class="menu-item"><a href="#">Student Life</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                            <div id="gdlr-core-custom-menu-widget-4" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                <h3 class="kingster-widget-title">University </h3><span class="clear"></span>
                                <div class="menu-academics-container">
                                    <ul id="menu-academics" class="gdlr-core-custom-menu-widget gdlr-core-menu-style-plain">
                                        <li class="menu-item"><a href="#">Sports</a></li>
                                        <li class="menu-item"><a href="#">Counselling</a></li>
                                        <li class="menu-item"><a href="#">Library</a></li>
                                        <li class="menu-item"><a href="#">Bursary</a></li>
                                        <li class="menu-item"><a href="#">MIS</a></li>
                                        <li class="menu-item"><a href="adminpanel.php">admin</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="kingster-copyright-wrapper">
                    <div class="kingster-copyright-container kingster-container clearfix">
                        <div class="kingster-copyright-left kingster-item-pdlr">Copyright All Right Reserved 2025, Adeyemi Federal Univsersity, Ondo</div>
                        <div class="kingster-copyright-right kingster-item-pdlr">
                            <div class="gdlr-core-social-network-item gdlr-core-item-pdb  gdlr-core-none-align" id="div_1dd7_112">
                           <h6 style="padding-left: 30px; color:#ffffff;"> Follow us:</h6>
                           <a href="https://www.facebook.com/aceondo.edu.ng" target="_blank" class="gdlr-core-social-network-icon" title="facebook">
									<i class="fa fa-facebook" ></i>
								</a>
								
								<a href="https://www.linkedin.com/in/adeyemi-fed-university-ondo-nigeria/" target="_blank" class="gdlr-core-social-network-icon" title="linkedin">
									<i class="fa fa-linkedin" ></i>
								</a>
								<a href="#" target="_blank" class="gdlr-core-social-network-icon" title="skype">
									<i class="fa fa-skype" ></i>
								</a>
								<a href="https://x.com/aceondoofficial" target="_blank" class="gdlr-core-social-network-icon" title="twitter">
									<i class="fa fa-twitter" ></i>
								</a>
								<a href="https://www.instagram.com/aceondoofficial" target="_blank" class="gdlr-core-social-network-icon" title="instagram">
									<i class="fa fa-instagram" ></i>
								</a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>