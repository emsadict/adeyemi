
<header class="kingster-header-wrap kingster-header-style-plain  kingster-style-menu-right kingster-sticky-navigation kingster-style-fixed" data-navigation-offset="75px">
                <div class="kingster-header-background"></div>
                <div class="kingster-header-container  kingster-container">
                    <div class="kingster-header-container-inner clearfix">
                        <div class="kingster-logo  kingster-item-pdlr">
                            <div class="kingster-logo-inner">
                                <a class="" href="index.html"><img src="images/logo-2.png" alt="" /></a>
                            </div>
                        </div>
                        <div class="kingster-navigation kingster-item-pdlr clearfix ">
                            <div class="kingster-main-menu" id="kingster-main-menu">
                                <ul id="menu-main-navigation-1" class="sf-menu">
                                    <li class="menu-item menu-item-home menu-item-has-children kingster-normal-menu"><a href="index.php" class="sf-with-ul-pre">Home</a>
                                        
                                    </li>
                                    <li class="menu-item menu-item-has-children kingster-normal-menu"><a href="#" class="sf-with-ul-pre">Pages</a>
                                        <ul class="sub-menu">
                                            <li class="menu-item" data-size="60"><a href="about-us.html">about</a></li>
                                            <li class="menu-item menu-item-has-children" data-size="60"><a href="blog-full-right-sidebar-with-frame.html" class="sf-with-ul-pre">Blog</a>
                                                <ul class="sub-menu">
                                                    <li class="menu-item menu-item-has-children"><a href="blog-full-right-sidebar-with-frame.html" class="sf-with-ul-pre">Blog Full</a>
                                                        <ul class="sub-menu">
                                                            <li class="menu-item"><a href="blog-full-right-sidebar-with-frame.html">Blog Full Right Sidebar With Frame</a></li>
                                                            <li class="menu-item"><a href="blog-full-left-sidebar-with-frame.html">Blog Full Left Sidebar With Frame</a></li>
                                                            <li class="menu-item"><a href="blog-full-both-sidebar-with-frame.html">Blog Full Both Sidebar With Frame</a></li>
                                                            <li class="menu-item"><a href="blog-full-right-sidebar.html">Blog Full Right Sidebar</a></li>
                                                            <li class="menu-item"><a href="blog-full-left-sidebar.html">Blog Full Left Sidebar</a></li>
                                                            <li class="menu-item"><a href="blog-full-both-sidebar.html">Blog Full Both Sidebar</a></li>
                                                        </ul>
                                                    </li>
                                                    <li class="menu-item menu-item-has-children"><a href="blog-grid-3-columns-no-space.html" class="sf-with-ul-pre">Blog Grid</a>
                                                        <ul class="sub-menu">
                                                            <li class="menu-item"><a href="blog-grid-2-columns.html">Blog Grid 2 Columns</a></li>
                                                            <li class="menu-item"><a href="blog-grid-3-columns.html">Blog Grid 3 Columns</a></li>
                                                            <li class="menu-item"><a href="blog-grid-4-columns.html">Blog Grid 4 Columns</a></li>
                                                            <li class="menu-item"><a href="blog-grid-2-columns-no-space.html">Blog Grid 2 Columns No Space</a></li>
                                                            <li class="menu-item"><a href="blog-grid-3-columns-no-space.html">Blog Grid 3 Columns No Space</a></li>
                                                            <li class="menu-item"><a href="blog-grid-4-columns-no-space.html">Blog Grid 4 Columns No Space</a></li>
                                                        </ul>
                                                    </li>

                                                    <li class="menu-item"><a href="standard-post-type.html">Single Post</a></li>
                                                </ul>
                                            </li>
                                            <li class="menu-item" data-size="60"><a href="contact.php" class="sf-with-ul-pre">Contact</a>
                                                
                                            </li>
                                            <li class="menu-item menu-item-has-children" data-size="60"><a href="portfolio-3-columns.html" class="sf-with-ul-pre">Portfolio</a>
                                                <ul class="sub-menu">
                                                    <li class="menu-item menu-item-has-children"><a class="sf-with-ul-pre">Portfolio Grid</a>
                                                        <ul class="sub-menu">
                                                            <li class="menu-item"><a href="portfolio-2-columns.html">Portfolio 2 Columns</a></li>
                                                            <li class="menu-item"><a href="portfolio-3-columns.html">Portfolio 3 Columns</a></li>
                                                            <li class="menu-item"><a href="portfolio-4-columns.html">Portfolio 4 Columns</a></li>
                                                            <li class="menu-item"><a href="portfolio-5-columns.html">Portfolio 5 Columns</a></li>
                                                            <li class="menu-item"><a href="portfolio-2-columns-with-frame.html">Portfolio 2 Columns With Frame</a></li>
                                                            <li class="menu-item"><a href="portfolio-3-columns-with-frame.html">Portfolio 3 Columns With Frame</a></li>
                                                            <li class="menu-item"><a href="portfolio-4-columns-with-frame.html">Portfolio 4 Columns With Frame</a></li>
                                                            <li class="menu-item"><a href="portfolio-2-columns-no-space.html">Portfolio 2 Columns No Space</a></li>
                                                            <li class="menu-item"><a href="portfolio-3-columns-no-space.html">Portfolio 3 Columns No Space</a></li>
                                                            <li class="menu-item"><a href="portfolio-4-columns-no-space.html">Portfolio 4 Columns No Space</a></li>
                                                            <li class="menu-item"><a href="portfolio-5-columns-no-space.html">Portfolio 5 Columns No Space</a></li>
                                                        </ul>
                                                    </li>
                                                    <li class="menu-item menu-item-has-children"><a class="sf-with-ul-pre">Portfolio Masonry</a>
                                                        <ul class="sub-menu">
                                                            <li class="menu-item"><a href="portfolio-masonry-4-columns.html">Masonry 4 Columns</a></li>
                                                            <li class="menu-item"><a href="portfolio-masonry-3-columns.html">Masonry 3 Columns</a></li>
                                                            <li class="menu-item"><a href="portfolio-masonry-2-columns.html">Masonry 2 Columns</a></li>
                                                            <li class="menu-item"><a href="portfolio-masonry-4-columns-no-space.html">Masonry 4 Columns No Space</a></li>
                                                            <li class="menu-item"><a href="portfolio-masonry-3-columns-no-space.html">Masonry 3 Columns No Space</a></li>
                                                            <li class="menu-item"><a href="portfolio-masonry-2-columns-no-space.html">Masonry 2 Columns No Space</a></li>
                                                        </ul>
                                                    </li>

                                                 <li class="menu-item menu-item-has-children"><a class="sf-with-ul-pre" href="singleportfolio.html">Single Portfolio</a></li>
                                                </ul>
                                            </li>
                                            <li class="menu-item" data-size="60"><a href="gallery.html">Gallery</a></li>
                                            <li class="menu-item" data-size="60"><a href="price-table.html">Price Table</a></li>
                                            <li class="menu-item" data-size="60"><a href="maintenance.html">Maintenance</a></li>
                                            <li class="menu-item" data-size="60"><a href="coming-soon.html">Coming Soon</a></li>
                                            <li class="menu-item" data-size="60"><a href="404.html">404 Page</a></li>
                                        </ul>
                                    </li>
                                    <li class="menu-item current-menu-item menu-item-has-children kingster-mega-menu" ><a href="organogram.php" class="sf-with-ul-pre">Structure</a>
                                        <div class="sf-mega sf-mega-full ">
                                            <ul class="sub-menu">
                                                <li class="menu-item menu-item-has-children" data-size="15"><a  href="vco.php" class="sf-with-ul-pre">Vice-Chancellor's Office</a>
                                                    <ul class="sub-menu">
                                                        <li class="menu-item"><a href="bachelor-of-science-in-business-administration.html">Legal Unit</a></li>
                                                        <li class="menu-item"><a href="school-of-law.html">Public Relations Unit</a></li>
                                                        <li class="menu-item"><a href="engineering.html">Identity Cards Units</a></li>
                                                        <li class="menu-item"><a href="engineering.html">Internal Audit Unit</a></li>
                                                        <li class="menu-item"><a href="medicine.html">SERVICOM/ACTM</a></li>
                                                        <li class="menu-item"><a href="art-science.html">MIS</a></li>
                                                      
                                                    </ul>
                                                </li>
                                                <li class="menu-item menu-item-has-children" data-size="15"><a href="directorate.php" class="sf-with-ul-pre">Directorates</a>
                                                    <ul class="sub-menu">
                                                        <li class="menu-item"><a href="directorate-main.php">Preliminary Studies</a></li>
                                                        <li class="menu-item"><a href="physics.html">Physics</a></li>
                                                        <li class="menu-item"><a href="#">Chemistry</a></li>
                                                        <li class="menu-item"><a href="#">Music</a></li>
                                                        <li class="menu-item"><a href="#">Computer Science</a></li>
                                                    </ul>
                                                </li> 
                                                
                                                <li class="menu-item menu-item-has-children" data-size="15"><a href="#" class="sf-with-ul-pre">Schools</a>
                                                <ul class="sub-menu">
                                                        <li class="menu-item"><a href="research.php">Adult, Non-formal &#038; Special Education</a></li>
                                                        <li class="menu-item"><a href="school-of-law.html">Arts &#038; Social Science</a></li>
                                                        <li class="menu-item"><a href="engineering.html">Early Childhood Education</a></li>
                                                        <li class="menu-item"><a href="medicine.html">General Education</a></li>
                                                        <li class="menu-item"><a href="art-science.html">School of Languages</a></li>
                                                        <li class="menu-item"><a href="art-science.html">School of Science</a></li>
                                                        <li class="menu-item"><a href="art-science.html">Vocational  &#038; Technical Education </a></li>
                                                    </ul>
                                                </li> 
                                                <li class="menu-item menu-item-has-children" data-size="15"><a href="units.php" class="sf-with-ul-pre">Units</a>
                                                    <ul class="sub-menu">
                                                        <li class="menu-item"><a href="services.php">Busary</a></li>
                                                        <li class="menu-item"><a href="#">Audit</a></li>
                                                        <li class="menu-item"><a href="finance-faculty.html">Faculty Page</a></li>
                                                        <li class="menu-item"><a href="#">Single Course</a></li>
                                                    </ul>
                                                </li> 
                                            </ul>
                                        </div>
                                    </li>
                                    <li class="menu-item menu-item-has-children kingster-normal-menu"><a href="#" class="sf-with-ul-pre">Admissions</a>
                                        <ul class="sub-menu">
                                            <li class="menu-item" data-size="60"><a href="#">Apply To AFUED</a></li>
                                            <li class="menu-item" data-size="60"><a href="scholarships.html">Scholarships</a></li>
                                            <li class="menu-item" data-size="60"><a href="alumni.html">Alumni</a></li>
                                        </ul>
                                    </li>
                                    <li class="menu-item menu-item-has-children kingster-normal-menu"><a href="#" class="sf-with-ul-pre">News</a>
                                        <ul class="sub-menu">
                                            <li class="menu-item" data-size="60"><a href="blog.php">Update</a></li>
                                            <li class="menu-item" data-size="60"><a href="events.php">Events</a></li>
                                            <li class="menu-item" data-size="60"><a href="researchs.php">Researches</a></li>


                                        </ul>
                                    </li>
                                    <li class="menu-item menu-item-has-children kingster-normal-menu"><a href="#" class="sf-with-ul-pre">About Us</a>
                                        <ul class="sub-menu">
                                            <li class="menu-item" data-size="60"><a href="facts.php">University Facts</a></li>
                                            <li class="menu-item" data-size="60"><a href="#">Governing Council</a></li>
                                            <li class="menu-item" data-size="60"><a href="gallery.php">Gallery</a></li>
                                        </ul>
                                    </li>
                                    <li class="menu-item menu-item-has-children kingster-normal-menu"><a href="#" class="sf-with-ul-pre">SUG</a>
                                        <ul class="sub-menu">
                                            <li class="menu-item" data-size="60"><a href="facts.php">University Facts</a></li>
                                            <li class="menu-item" data-size="60"><a href="course-list-2.html">Leadership</a></li>
                                        </ul>
                                    </li>
                                    <li class="menu-item kingster-normal-menu"><a href="university-life.html">University Life</a></li>
                                </ul>
                                <div class="kingster-navigation-slide-bar" id="kingster-navigation-slide-bar"></div>
                            </div>
                            <div class="kingster-main-menu-right-wrap clearfix ">
                                <div class="kingster-main-menu-search" id="kingster-top-search"><i class="icon_search"></i></div>
                                <div class="kingster-top-search-wrap">
                                    <div class="kingster-top-search-close"></div>
                                    <div class="kingster-top-search-row">
                                        <div class="kingster-top-search-cell">
                                            <form role="search" method="get" class="search-form" action="#">
                                                <input type="text" class="search-field kingster-title-font" placeholder="Search..." value="" name="s">
                                                <div class="kingster-top-search-submit"><i class="fa fa-search"></i></div>
                                                <input type="submit" class="search-submit" value="Search">
                                                <div class="kingster-top-search-close"><i class="icon_close"></i></div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>