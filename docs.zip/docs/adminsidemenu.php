
<h3 class="kingster-widget-title">Menu</h3><span class="clear"></span>
                                        <ul>
                                        <li> <a href="add_news.php">Post News</a></li>
                                            <li> <a href="create_event.php">Post Events</a></li>
                                            <li> <a href="create_research.php">Post Research </a></li>
                                            <li> <a href="manage_news.php">Manage News</a></li>
                                            <li> <a href="manage_event.php">Manage Events</a></li>
                                            <li> <a href="manage_research.php">Manage Research </a></li>
                                        </ul> 
